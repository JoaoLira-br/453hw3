# SCALAR PRODUCT REPORTS

The computation of the scalar product of Alice`s entries ([1,1,1,1,1,0,0,0,0,0]) and Bob`s entries ([3,3,3,3,3,3,3,3,3,3]) was successfully and securely completed.

# RESULTS SUMMARY

their output is 5. The reason for that is that all bob`s entries are 3 which when 3 modulo 2, because of 1 bit integer, becomes 1. Alice has 5 1s which match 5 times with Bob`s entries, thus resulting in a scalar product of 5.
